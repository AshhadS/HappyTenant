package com.example.tenantapp.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatImageButton;

import com.example.tenantapp.R;
import com.example.tenantapp.TranslationHelper;
import com.example.tenantapp.util.UserLanguageStore;

public class TranslationButton extends AppCompatImageButton {

    private TranslationHelper helper;

    public TranslationButton(Context context) {
        super(context);
        init(context);
    }

    public TranslationButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public TranslationButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        setImageResource(R.drawable.ic_translate); // add your own translate icon
        setOnClickListener(v -> {
            Toast.makeText(context, "Switching language...", Toast.LENGTH_SHORT).show();

            // Example: toggle EN ↔ AR (you can extend with preferences)
            String currentLang = UserLanguageStore.getInstance(context).getLang();
            String newLang = currentLang.equals("en") ? "ar" : "en";

            UserLanguageStore.getInstance(context).setLang(newLang);

            Toast.makeText(context,
                    "Language set to " + newLang.toUpperCase(),
                    Toast.LENGTH_SHORT).show();
        });
    }
}
